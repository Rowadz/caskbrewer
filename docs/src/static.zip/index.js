setTimeout(() => {
    alert('If you see this, you are good')
}, 4000);
alert(`
    This Alert is from the index.js file from the .zip file,
    Served and executed using BLOB and URL.createObjectURL()
`)